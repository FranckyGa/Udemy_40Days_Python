password = input("Enter a password :")

while password != "pass123":
    password = input("Enter a password :")

print("password was correct !")

x = 1

while x <= 6:
    print(x)
    x = x + 1
