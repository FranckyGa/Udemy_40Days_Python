user_prompt = "Enter a todo :"

todos = []

while True :
    todo = input(user_prompt)

    #Capitalize = 1st letter in captial letter /// titie = 1st letter of each word in capital letter
    print(todo.capitalize())
    todos.append(todo)


toto = input("write your name")
